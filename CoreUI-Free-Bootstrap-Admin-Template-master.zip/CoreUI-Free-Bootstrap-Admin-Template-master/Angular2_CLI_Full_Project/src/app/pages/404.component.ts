import { Component }        from '@angular/core';

@Component({
    templateUrl: '404.component.html'
})
export class p404Component {

    constructor() { }

}
